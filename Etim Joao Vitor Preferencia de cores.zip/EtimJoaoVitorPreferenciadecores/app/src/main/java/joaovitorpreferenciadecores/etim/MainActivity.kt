package joaovitorpreferenciadecores.etim

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import joaovitorpreferenciadecores.etim.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding

    private var cor = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        supportActionBar!!.hide()
        window.statusBarColor = Color.WHITE
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.cor1.setOnClickListener{
            cor = "#673AB7"
        }

        binding.cor2.setOnClickListener{
            cor = "#3F51B5"
        }

        binding.cor3.setOnClickListener{
            cor = "#2196F3"

        }

        binding.cor4.setOnClickListener{
            cor = "#00BCD4"

        }
    }
}