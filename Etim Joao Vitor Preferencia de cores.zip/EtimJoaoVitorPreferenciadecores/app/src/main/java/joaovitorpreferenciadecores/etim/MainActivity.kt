package joaovitorpreferenciadecores.etim

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
import joaovitorpreferenciadecores.etim.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    companion object {
        const val PREFER_COR = "color_prefs.xml"
    }

    private var cor = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        supportActionBar!!.hide()
        window.statusBarColor = Color.WHITE
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.cor1.setOnClickListener {
            cor = "#673AB7"
            salvarCor(cor)
        }

        binding.cor2.setOnClickListener {
            cor = "#3F51B5"
            salvarCor(cor)
        }

        binding.cor3.setOnClickListener {
            cor = "#2196F3"
            salvarCor(cor)
        }

        binding.cor4.setOnClickListener {
            cor = "#00BCD4"
            salvarCor(cor)
        }
    }

    override fun onResume() {
        super.onResume()

        val preferencias = getSharedPreferences(PREFER_COR, MODE_PRIVATE)
        val cor = preferencias.getString("cor", "")

        if(cor!!.isNotEmpty()){
            binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))
        }
    }

    private fun salvarCor(cor: String) {

        binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        binding.btnMudarCor.setOnClickListener { view ->
            val preferencias = getSharedPreferences(PREFER_COR, MODE_PRIVATE)
            val editor = preferencias.edit()
            editor.putString("cor", cor)
            editor.putString("nome", "joão vitor")
            editor.putString("sobrenome", "cassiano")
            editor.putInt("idade", 18)
            editor.apply()

        }
    }
    private fun snackBar(view:View){
        val snackbar = Snackbar.make(view, "Cor de fundo alterada com sucesso!", Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction("OK"){

        }
        snackbar.setActionTextColor(Color.BLUE)
        snackbar.setBackgroundTint(Color.LTGRAY)
        snackbar.setTextColor(Color.GREEN)
        snackbar.show()

    }
}